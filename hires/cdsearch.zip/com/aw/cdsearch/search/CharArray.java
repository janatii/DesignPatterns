/***
 * CharArray.java
 * Copyright 1996, 1997 Addison Wesley Longman.
 ***/

package com.aw.cdsearch.search;

/***
 * A class wrapping a char[] for the sole intent of using it as an index
 * into a Hashtable.  The char[] is made public to avoid the overhead
 * of copying it.  The only point to this class is to allow some of the
 * efficiency flexibilities denied by String and StringBuffer.
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

public final class CharArray {
  /***
   * The char[] wrapped by the CharArray instance.
   ***/
  public char[] value;

  /***
   * Constructs a new CharArray.
   *
   * @param val  The char[] to wrap.
   ***/
  public CharArray(char[] val) {
     value = val;
  }


  /***
   * @return A hashcode value identical to the value that would be returned
   *         by java.lang.String.
   ***/
  // The algorithm used to generate the hash value is borrowed from
  // java.lang.String, although the implementation is slightly different.
  public int hashCode() {
    int hash = 0, offset = 0, skip, count;
    
    if (value.length < 16) {
      for (count = value.length ; count > 0; count--) {
	hash = 37 * hash + value[offset++];
      }
    } else {
      skip = value.length / 8;
      for (count = value.length; count > 0; count -= skip, offset += skip) {
	hash = 39 * hash + value[offset];
      }
    }
    return hash;
  }

  /***
   * @param object  An object to test for equality.
   * @return true if the object is equal, meaning that it must be a CharArray
   *              instance, be of the same length, and have the exact same
   *              values in each one of its array elements.  false otherwise.
   ***/
  public boolean equals(Object object) {
    if ((object != null) && (object instanceof CharArray)) {
      char[] other = ((CharArray)object).value;
      int count;
      if (value.length == other.length) {
	count = value.length;

	while (count-- != 0) {
	  if (value[count] != other[count])
	    return false;
	}

	return true;
      }
    }
    return false;
  }

  /***
   * @return A String representation of the CharArray.
   ***/
  public String toString() {
    return new String(value);
  }
}

