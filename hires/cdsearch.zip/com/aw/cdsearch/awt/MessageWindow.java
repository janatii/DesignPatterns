/***
 * MessageWindow.java
 * Copyright 1996, 1997 Addison Wesley Longman.
 ***/
package com.aw.cdsearch.awt;

import java.lang.*;
import java.awt.*;

/***
 * A simple class to display a multiple line message and an ok button at
 * the bottom.  This class uses the MultiLineLabel class by David Flanagan,
 * Copyright by O'Reilly and Associates.  The MultiLineLabel source code
 * says you may study, use, modify, and distribute the example for any
 * purpose.<p>

 * This class extends Frame instead of Dialog because Dialog implementations
 * have proven to be buggy across different platforms and browsers.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

public final class MessageWindow extends Frame {
  MultiLineLabel area;
  Button okButton;
  Panel buttonPanel;

  /***
   * @param message  The message to display in the window.  Newlines in
   *       the message determine the start of new lines in the display,
   *       i.e., no line wrapping is done.
   ***/
  public MessageWindow(String message) {
    super("Message");
    area = new MultiLineLabel(message);
    okButton = new Button("Ok");

    add("Center", area);
    buttonPanel = new Panel();
    buttonPanel.add(okButton);
    add("South", buttonPanel);
    pack();
  }

  /***
   * Action event handler for the window.  If the event target is the
   * ok button, the window hides and disposes its peer resources.
   ***/
  public boolean action(Event event, Object arg) {
    if(event.target == okButton) {
      hide();
      dispose();
      return true;
    }
    return false;
  }

}
