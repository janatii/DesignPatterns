/***
 * MessageArea.java
 * Copyright 1996, 1997 Addison Wesley Longman.
 ***/

package com.aw.cdsearch.awt;

import java.lang.*;

/***
 * An interface for showing messages.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

public interface MessageArea {
  /***
   * Displays a message however the implementing class decides.
   *
   * @param message The message to display.
   ***/
  public void showMessage(String message);
}
