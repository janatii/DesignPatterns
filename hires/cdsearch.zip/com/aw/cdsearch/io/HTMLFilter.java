/***
 * HTMLFilter.java
 * Copyright 1996, 1997 Addison Wesley Longman.
 ***/
package com.aw.cdsearch.io;

import java.lang.*;
import java.io.*;

import savarese.regex.*;

/***
 * This class is a WordFilter that extracts all strings comprised of
 * valid word characters (i.e, [0-9a-z_A-Z]) from an HTML file,
 * ignoring tags, special characters, punctuation, etc.
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 * @see WordFilter
 ***/

public class HTMLFilter extends WordFilter {
  /***
   * A Perl 4 regular expression representing an HTML tag.
   ***/
  protected static final String tagExpression  = "<[^>]*>";

  /***
   * A Perl 4 regular expression representing a word in an HTML file.
   ***/
  protected String wordExpression;

  /***
   * A regular expression matcher used to extract potential tokens.
   ***/
  protected FastMatcher tokenMatcher;

  /***
   * Creates an HTMLFilter with an associated InputStream from which
   * to generate tokens.  Initializes tokenMatcher, associating it
   * with the <b>stream</b> parameter as input.
   *
   * @param stream  The InputStream to be filtered by the HTMLFilter.
   * @exception IOException If there is an error in binding the InputStream.
   ***/
  public HTMLFilter(InputStream stream) throws IOException {
    super(stream);
    wordExpression = "\\w+";

    try {
      tokenMatcher =
	new FastMatcher(tagExpression + "|" + "\\w+", true);
      tokenMatcher.setInput(stream);
    } catch(MalformedExpression e) {
      // This should never happen, but it's good to have a print statement
      // here when trying out a new default regular expression.
      System.err.println(
         "Unexpected bad regular expression in HTMLFilter(InputStream)");
    }
  }

  public HTMLFilter(String expression, InputStream stream)
    throws IOException, MalformedExpression {
    super(stream);
    wordExpression = expression;
    tokenMatcher =
      new FastMatcher(tagExpression + "|" + wordExpression, true);
    tokenMatcher.setInput(stream);
  }

  /***
   * This method interprets the HTMLFilter's associated InputStream as an
   * HTML file, which it views as a container of Strings with formatting
   * information irrelevant to the information content of the document.
   * This method fetches the next <i>relevant</i> String from the
   * InputStream, filtering out HTML tags and punctuation.
   *
   * @return The next word in the associated InputStream.  If there
   * are no more words, returns null.
   * @exception IOException  If there is an error in reading the InputStream
   * to obtain the next word.
   ***/
  public String nextWord() throws IOException {
    String result;
    MatchResult match;

    while((match = tokenMatcher.search()) != null){
      result = match.group(0);
      if(result.charAt(0) != '<')
	return result;
    }

    return null;
  }
}
