/***
 * Index.java
 * Copyright 1996, 1997 Addison Wesley Longman.
 ***/

package com.aw.cdsearch.search;

import java.lang.*;
import java.io.*;
import java.util.*;
import java.net.*;

import savarese.regex.*;

import com.aw.cdsearch.awt.MessageArea;

/***
 * A simple structure storing information about an indexed block.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

final class BlockEntry {
  /***
   * The a number refering to the file containing the block.  <b>fileNumber</b>
   * is used to index an array of <b>FileEntry</b> instances representing
   * the indexed files.
   ***/
  char file;

  /***
   * The HTML anchor used to name this block.
   ***/
  String anchor;
}


/***
 * A simple structure storing information about an indexed file.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

final class FileEntry {
  /***
   * The relative file name and title of the file.
   ***/
  String filename, title;
}


/***
 * A class storing the index information and providing methods to search
 * the index or the indexed files. <p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

public class Index {
  /***
   * Constants describing the mode of search to perform: <p>
   * <ul><li> SEARCH_EXACT - look for a word exactly matching the search term
   *     <li> SEARCH_SUBSTRING - look for a word containing the search term
   *     <li> SEARCH_REGEX - look for a Perl 4 regular expression </ul>
   ***/
  public static final int SEARCH_EXACT = 0, SEARCH_SUBSTRING = 1,
                          SEARCH_REGEX = 2;
  /***
   * Constants describing the kind of search to perform: <p>
   * <ul><li> SEARCH_PREINDEXED - search the loaded index
   *     <li> SEARCH_EXHAUSTIVE - search the files exhaustively </ul>
   ***/
  public static final int SEARCH_PREINDEXED = 3, SEARCH_EXHAUSTIVE = 4;

  // Array of all indexed blocks
  BlockEntry[] blockArray;

  // Array of all indexed files
  FileEntry [] fileArray;

  // Hashtable of indexed words.  A lookup returns a char[] containing
  // the block numbers where the word occurs.
  Hashtable wordIndex;

  // Regular expressions used for spliting search expressions by boolean
  // operators and white space
  FastMatcher andMatcher, orMatcher, andNotMatcher, whitespaceMatcher,
              phraseMatcher;

  /***
   * Tests if a token is a regular expression meta character.
   *
   * @param token  The token to test.
   * @return if the token is a regular expression meta character,
   *         false otherwise.
   ***/
  static private boolean isMetachar(char token) {
    return (token == '*' || token == '?' || token == '+' ||
            token == '[' || token == ']' || token == '(' ||
            token == ')' || token == '|' || token == '^' ||
            token == '$' || token == '.');
  }

  /***
   * Default constructor for Index.  Initializes regular expressions
   * used by the indexer to parse queries.
   ***/
  public Index() {
    try {
      andMatcher        = new FastMatcher("\\band\\b", false);
      orMatcher         = new FastMatcher("\\bor\\b", false);
      andNotMatcher     = new FastMatcher("\\bandnot\\b", false);
      whitespaceMatcher = new FastMatcher("\\s+", true);
      phraseMatcher     = new FastMatcher("\"[^\"]*\"", false);
    } catch(MalformedExpression e){
      // This should not be called because the expressions should be
      // correct.  However, if the expression is changed, this is
      // useful for debugging.
      System.err.println("Unexpected MalformedExpression caught in" +
                         " Index():\n" + e.getMessage());
      return;
    }
  }


  /***
   * Loads the indexed block data from a URL.
   *
   * @param fileURL The URL of the block index file.
   * @return the number of words written to the word index file.  This
   *         value is stored in the block index file.  Therfore the
   *         block index file must be read before the word index file.
   * @exception IOException if there an error occurs while reading the file.
   ***/
  public int readBlockIndex(String fileURL) throws IOException {
    int cnt, wordsWritten;
    char size;
    URL url;
    DataInputStream input;

    try {
      url = new URL(fileURL);
    } catch(MalformedURLException e){
      throw new IOException("Caught MalformedURLException for url: " +
			    fileURL + "\nMessage: " + e.getMessage());
    }

    input =
      new DataInputStream(new BufferedInputStream(url.openStream(), 4096));

    wordsWritten  = input.readInt();
    size          = input.readChar();
    blockArray    = new BlockEntry[size];

    for(cnt=0; cnt < blockArray.length; cnt++){
      blockArray[cnt]        = new BlockEntry();
      blockArray[cnt].file   = input.readChar();
      // Beware of readLine() bug.  Does readLine() return newline?
      blockArray[cnt].anchor = input.readLine();
    }

    // We don't close the InputStream because URL's automatically close
    // on EOF.
    return wordsWritten;
  }


  /***
   * Loads the indexed file data from a URL.
   *
   * @param fileURL The URL of the file index.
   * @exception IOException if there an error occurs while reading the file.
   ***/
  public void readFileIndex(String fileURL) throws IOException {
    int cnt;
    char size;
    URL url;
    DataInputStream input;

    try {
      url = new URL(fileURL);
    } catch(MalformedURLException e){
      throw new IOException("Caught MalformedURLException for url: " +
			    fileURL + "\nMessage: " + e.getMessage());
    }

    input =
      new DataInputStream(new BufferedInputStream(url.openStream(), 4096));

    size         = input.readChar();
    fileArray    = new FileEntry[size];

    for(cnt=0; cnt < fileArray.length; cnt++){
      fileArray[cnt]          = new FileEntry();
      // Beware of readLine() bug.  Does readLine() return newline?
      fileArray[cnt].filename = input.readLine();
      fileArray[cnt].title    = input.readLine();
    }

    // We don't close the InputStream because URL's automatically close
    // on EOF.
  }

  /***
   * Loads the indexed word data from a URL.
   *
   * @param fileURL The URL of the word index file.
   * @param words  The number of words stored in the file.  This number
   *               should be obtained from readBlockIndex() prior to calling
   *               this method.
   * @exception IOException if there an error occurs while reading the file.
   ***/
  public void readWordIndex(String fileURL, int words) throws IOException {
    int size;
    URL url;
    DataInputStream input;
    String word;
    char[] blockList;

    try {
      url = new URL(fileURL);
    } catch(MalformedURLException e){
      throw new IOException("Caught MalformedURLException for url: " +
			    fileURL + "\nMessage: " + e.getMessage());
    }

    input
      = new DataInputStream(new BufferedInputStream(url.openStream(), 16384));
    // Indices will have between 6000 and 12000 words, so allocate
    // sufficient capacity.
    if(words < 6000)
      wordIndex = new Hashtable(words);
    else
      wordIndex = new Hashtable(6000);

    while(words-- > 0) {
      word = input.readUTF();
      size = input.readInt();
      blockList = new char[size];
      for(size = 0; size < blockList.length; size++)
	blockList[size] = input.readChar();
      wordIndex.put(new CharArray(word.toCharArray()), blockList);
    }

    // We don't close the InputStream because URL's automatically close
    // on EOF.
  }

  /***
   * Escapes the regular expression metacharacters in an expression,
   * <i>normalizing</i> it to a regular string if interpreted as a
   * regular expression.
   *
   * @param expression  The string expression to normalize.
   * @return the normalized string.
   ***/
  private String normalizeExpression(String expression) {
    char ch;
    int index, length;
    StringBuffer buffer;

    length = expression.length();
    buffer = new StringBuffer(2*length);

    for(index=0; index < length; index++){
      ch = expression.charAt(index);
      if(Index.isMetachar(ch))
	buffer.append('\\');
      buffer.append(ch);
    }

    return buffer.toString();
  }


  /***
   * Searches the index for a single exact match.
   *
   * @param expression  The expression to match.
   * @return a char[] containing the block numbers where the match occurs.
   *         null if the expression is not in the index.
   ***/
  protected char[] searchExact(String expression) {
      Object blockList;

      if((blockList = wordIndex.get(new CharArray(expression.toCharArray())))
	 != null)
	return ((char[])blockList);

      return null;
  }


  /***
   * Searches the index for words matching a single regular expression.
   *
   * @param expression  The regular expression to match.
   * @return a Vector of SearchResult elements containing the match data.
   * @exception MalformedExpression if the regular expression is
   *            invalid.
   * @IOException  If an I/O error occurs while doing the search.
   ***/
  protected Vector searchIndexRegex(String expression)
    throws MalformedExpression, IOException {
      char blockIndex;
      int block;
      char[] blockList;
      FastMatcher expressionMatcher;
      Vector results = new Vector();
      Enumeration keys;
      CharArray key;

      if(expression.length() == 0)
	return results;

      expressionMatcher = new FastMatcher(expression, false);

      for(keys = wordIndex.keys(); keys.hasMoreElements();) {
	key = (CharArray)keys.nextElement();
	//if((match = expressionMatcher.search()) != null)
	if(expressionMatcher.match(key.value)) {
	  String strKey, name, url, context;

	  blockList = (char[])(wordIndex.get(key));
	  strKey = key.toString();
	  for(block = 0; block < blockList.length; block++){
	    blockIndex = blockList[block];

	    if(blockArray[blockIndex].anchor.length() == 0) {
	      name = fileArray[blockArray[blockIndex].file].title;
	      url  = fileArray[blockArray[blockIndex].file].filename;
	      context = null;
	    } else {
	      context = fileArray[blockArray[blockIndex].file].filename;
	      name    = fileArray[blockArray[blockIndex].file].title
		+ ": " + blockArray[blockIndex].anchor;
	      url     = "#" + blockArray[blockIndex].anchor;
	    }
	    name = strKey + " -- " + name;
	    results.addElement(new SearchResult(name, context, url));
	  }
	}
      }

      return results;
  }


  /***
   * Searches the index for words containing a substring.  A substring
   * search expression can consist of a series of or'ed substrings.
   * Whitespace between substrings is an implicit or.
   *
   * @param expression  The substring query.
   * @return a Vector of SearchResult elements containing the match data.
   * @exception MalformedExpression if the substring results
   *            in the creation of an invalid regular expression.
   * @IOException  If an I/O error occurs while doing the search.
   ***/
  protected Vector searchIndexSubstring(String expression)
    throws MalformedExpression, IOException {
      char blockIndex;
      int block;
      char[] blockList;
      MatchResult match;
      FastMatcher expressionMatcher;
      Vector results = new Vector();
      Enumeration keys;
      CharArray key;
      String word;
      Enumeration orWords, words;

      // Split the query into boolean or arguments.
      orWords = Util.split(orMatcher,
			   expression.trim()).elements();

      expression = null;

      // Create a regular expression consisting of the or'ed substrings
      while(orWords.hasMoreElements()) {
	String next;

	words =
	  Util.split(whitespaceMatcher,
		     ((String)orWords.nextElement()).trim()).elements();

	while(words.hasMoreElements()) {
	  next = (String)words.nextElement();
	  if(next.length() > 0) {
	    next = normalizeExpression(next);
	    if(expression == null)
	      expression = next;
	    else
	      expression = expression + "|" + next;
	  }
	}
      }

      if(expression == null)
	return results;

      expressionMatcher = new FastMatcher(expression, false);

      for(keys = wordIndex.keys(); keys.hasMoreElements();) {
	key = (CharArray)keys.nextElement();
	expressionMatcher.setInput(key.value);
	if(expressionMatcher.search() != null) {
	  String strKey, name, url, context;

	  blockList = (char[])(wordIndex.get(key));
	  strKey = key.toString();
	  for(block = 0; block < blockList.length; block++){
	    blockIndex = blockList[block];

	    if(blockArray[blockIndex].anchor.length() == 0) {
	      name = fileArray[blockArray[blockIndex].file].title;
	      url  = fileArray[blockArray[blockIndex].file].filename;
	      context = null;
	    } else {
	      context = fileArray[blockArray[blockIndex].file].filename;
	      name    = fileArray[blockArray[blockIndex].file].title
		+ ": " + blockArray[blockIndex].anchor;
	      url     = "#" + blockArray[blockIndex].anchor;
	    }
	    name = strKey + " -- " + name;
	    results.addElement(new SearchResult(name, context, url));
	  }
	}
      }

      return results;
  }

  /***
   * Parse a boolean search query and search for exact matches of the
   * arguments and combining the results appropriately.  Exact match
   * queries accept the and, or, andnot, boolean operators.
   * 
   * @param expression  The exact string query.
   * @return a Vector of SearchResult elements containing the match data.
   * @IOException  If an I/O error occurs while doing the search.
   ***/
  protected Vector searchIndexExact(String expression) throws IOException {
    boolean firstRun;
    int block;
    char[] blockList;
    String name, url, context;
    Vector orArgs, andArgs, results, andSets;
    Enumeration exp, subExp, atomExp, andExp, andNotExp;
    BitSet found, andFound, andSet;

    found    = new BitSet(blockArray.length);
    andFound = new BitSet(blockArray.length);
    andSet   = new BitSet(blockArray.length);

    // Split the expression up into the argument to or operators
    orArgs  = Util.split(orMatcher, expression.trim());
    andArgs = new Vector();
    andSets = new Vector();

    // For each of the or arguments, store a vector of and arguments
    for(exp = orArgs.elements(); exp.hasMoreElements();)
      andArgs.addElement(Util.split(andMatcher,
				    ((String)exp.nextElement())));

    for(exp = andArgs.elements(); exp.hasMoreElements();) {
      firstRun = true;
      for(subExp = ((Vector)exp.nextElement()).elements();
	  subExp.hasMoreElements();) {
	atomExp =
	  Util.split(andNotMatcher,
		     ((String)subExp.nextElement()).trim()).elements();

	andExp = Util.split(whitespaceMatcher,
			    ((String)atomExp.nextElement()).trim()).elements();

	andSets.setSize(0);
	andSet.xor(andSet); // clear bits

	// Process and arguments
	while(andExp.hasMoreElements()) {
	  name = (String)andExp.nextElement();
	  blockList = searchExact(name.toLowerCase());

	  if(blockList != null) {
	    BitSet set = new BitSet(blockArray.length);

	    for(block = 0; block < blockList.length; block++)
	      set.set(blockList[block]);

	    andSets.addElement(set);
	  } else
	    andSets.addElement(new BitSet(blockArray.length));
	    
	}   // end while

	andExp = andSets.elements(); 
	if(andExp.hasMoreElements()) {
	  andSet.or((BitSet)andExp.nextElement());

	  while(andExp.hasMoreElements()) {
	    andSet.and((BitSet)andExp.nextElement());
	  }
	}

	while(atomExp.hasMoreElements()) {
	  andExp = Util.split(whitespaceMatcher,
		      ((String)atomExp.nextElement()).trim()).elements();

	  while(andExp.hasMoreElements()) {
	    name = (String)andExp.nextElement();
	    blockList = searchExact(name.toLowerCase());
	  
	    if(blockList != null) {
	      for(block = 0; block < blockList.length; block++)
		andSet.clear(blockList[block]);
	    } // end if(blockList != null)
	  }   // end while
	}

	if(firstRun) {
	  andFound.or(andSet);
	  firstRun = false;
	} else
	  andFound.and(andSet);
      }     // end inner for
      found.or(andFound);
      andFound.xor(andFound); // clear bits
    }       // end outer for

    results = new Vector();

    for(block = 0; block < blockArray.length; block++){
      if(found.get(block)) {
	if(blockArray[block].anchor.length() == 0) {
	  name = fileArray[blockArray[block].file].title;
	  url  = fileArray[blockArray[block].file].filename;
	  context = null;
	} else {
	  context = fileArray[blockArray[block].file].filename;
	  name    = fileArray[blockArray[block].file].title
	    + ": " + blockArray[block].anchor;
	  url     = "#" + blockArray[block].anchor;
	}
	results.addElement(new SearchResult(name, context, url));
      }
    }

    return results;
  }


  /***
   * Execute a preindexed query.
   *
   * @param expression  The search query.
   * @param mode  The type of query, one of SEARCH_EXACT, SEARCH_SUBSTRING,
   *              or SEARCH_REGEX.
   * @return a Vector of SearchResult elements containing the match data.
   ***/
  public Vector searchIndex(String expression, int mode)
    throws MalformedExpression, IOException {
    if(mode == SEARCH_EXACT)
      return searchIndexExact(expression);
    else if(mode == SEARCH_REGEX)
      return searchIndexRegex(expression);
    else if(mode == SEARCH_SUBSTRING)
      return searchIndexSubstring(expression);
    else
      return new Vector();
  }


  /***
   * Execute an exhaustive query, searching all the indexed files in real time.
   *
   * @param baseURL  The URL of the root directory of the indexed file
   *                 hierarchy.
   * @param expression  The search query.
   * @param mode  The type of query, one of SEARCH_EXACT, SEARCH_SUBSTRING,
   *              or SEARCH_REGEX.
   * @return a Vector of SearchResult elements containing the match data.
   ***/
  public Vector searchExhaustive(String baseURL, String expression, int mode,
				 MessageArea area)
    throws MalformedURLException, IOException, MalformedExpression {
      int file;
      DataInputStream input;
      URL url;
      FastMatcher matcher;
      Vector results = new Vector();

      if(mode == SEARCH_EXACT || mode == SEARCH_SUBSTRING) {
	boolean appendBar; 
	String word;
	StringBuffer exp, nonPhraseExp;
	Enumeration orWords, words;
	MatchResult result;

	exp = new StringBuffer();
	appendBar = false;

	phraseMatcher.setInput(expression);

	if((result = phraseMatcher.search()) != null) {
	  String phrase;
	  boolean append;

	  append = false;

	  do {
	    phrase = result.group(0);

	    if(phrase.length() > 2) {
	      phrase = phrase.substring(1, phrase.length() - 1);
	      if(phrase.length() > 0) {
		if(append)
		  exp.append("|");
		else
		  append = true;

		if(mode == SEARCH_SUBSTRING)
		  exp.append(phrase);
		else
		  // Technically should do "\\b" + phrase + "\\b", but
		  // this will be faster and cover most of the cases.
		  exp.append("\\b" + phrase + "\\b");
	      }
	    }

	  } while((result = phraseMatcher.search()) != null);


	  orWords = Util.split(phraseMatcher, expression.trim()).elements();
	  nonPhraseExp = new StringBuffer();

	  while(orWords.hasMoreElements())
	    nonPhraseExp.append((String)orWords.nextElement());

	  expression = nonPhraseExp.toString();
	  if(expression.length() > 0)
	    appendBar = true;
	}

	orWords = Util.split(orMatcher,
			     expression.trim()).elements();

	while(orWords.hasMoreElements()) {
	  words =
	    Util.split(whitespaceMatcher,
		       ((String)orWords.nextElement()).trim()).elements();

	  do {
	    word = normalizeExpression((String)words.nextElement());

	    if(word.length() > 0) {
	      if(appendBar)
		exp.append("|");
	      else
		appendBar = true;
	      if(mode == SEARCH_SUBSTRING)
		exp.append(word);
	      else
		// Technically should do "\\b" + word + "\\b", but
		// this will be faster and cover most of the cases.
		exp.append("\\b" + word + "\\b");
	    }
	  } while(words.hasMoreElements());
	}

	expression = exp.toString();
	// debug
	//System.err.println("Expression: " + expression);
      }

      matcher = new FastMatcher(expression, false);

      for(file = 0; file < fileArray.length; file++) {
	if(area != null)
	  area.showMessage("Searching: " + fileArray[file].filename);
	url = new URL(baseURL + fileArray[file].filename);
	input =
	  new DataInputStream(new BufferedInputStream(url.openStream(), 4096));

	matcher.setInput(input);
	if(matcher.search() != null) {
	  results.addElement(new SearchResult(fileArray[file].title, null,
					      fileArray[file].filename));
	  continue;
	}
      }

      if(area != null)
	area.showMessage("Exhaustive Search Completed."); 

      return results;
    }

}
