/***
 * HTMLIndexer.java
 * Copyright 1996, 1997 Addison Wesley Longman.
 ***/
package com.aw.cdsearch.indexer;

import java.lang.*;
import java.io.*;
import java.util.*;

import com.aw.cdsearch.io.*;
import com.aw.cdsearch.awt.*;

import savarese.regex.*;

/***
 * A subclass of Indexer used to index HTML files.  It only implements
 * a constructor and the index() method.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 * @see Indexer
 ***/

public final class HTMLIndexer extends Indexer {
  static final String anchorExpression1 = "<a\\s+name\\s*=\\s*\"([^\"]+)\"";
  static final String anchorExpression2 = "<a\\s+name\\s*=\\s*([^\\s>]+)";
  //"<a\\s+name\\s*=\\s*\"?([^\\s\">]+)\"?\\s*>";

  private GroupMatcher anchorMatcher1, anchorMatcher2;

  /***
   * The default constructor for HTMLIndexer.  Initializes internal
   * data structures used to index HTML files.
   ***/
  public HTMLIndexer(){
    try {
      anchorMatcher1  = new GroupMatcher(anchorExpression1, false);
      anchorMatcher2  = new GroupMatcher(anchorExpression2, false);
    } catch(MalformedExpression e){
      // This should not be called because the expression should be
      // correct.  However, if the expression is changed, this is
      // useful for debugging.
      System.err.println("Unexpected MalformedExpressionLException caught in" +
			 " HTMLIndexer():\n" + e.getMessage());
      return;
    }
  }

  /***
   * This method takes a list of file names as input, indexes them, and
   * returns a RawIndex instance containing the raw index data.  It
   * is called by the Indexer createIndex() method.
   *
   * @param messageArea  A place to show messages during indexing.
   * @param indexDirectory The absolute path of the root directory of the files
   *                       being indexed, including the trailing /.
   * @param wordExpression  A regular expression to use to represent
   *                            a word.
   * @param filenameList  An Enumeration of file names to be indexed.  The
   *                      names should be of type String.
   * @return A RawIndex instance containing the resulting index.  Note,
   *         a better design would allow for multi-threading or an Observer
   *         to update while indexing to provide feedback.
   * @exception MalformedExpression
   *            If the word expression is a bad regular expression.
   ***/
  RawIndex index(MessageArea messageArea, String indexDirectory,
		 String wordExpression,	 Enumeration filenameList)
    throws MalformedExpression {
    boolean inTitle, foundTitle;
    char currentFile = 0, currentBlock = 0;
    int wordCount = 0;
    char blockNumber[];
    String filename, token, anchorName;
    StringBuffer title = new StringBuffer(100);
    Vector blockList = new Vector(400), fileList = new Vector(200);
    Hashtable wordIndex = new Hashtable();
    RawIndex index;
    InputStream input;
    HTMLTokenFilter filter;
    MatchResult anchor;
    WordEntry wordEntry;
    FileEntry fileEntry;
    BlockEntry blockEntry;
    Runtime runtime = Runtime.getRuntime();

    // Iterate through filenames and index each file.
    while(filenameList.hasMoreElements()){
      // A file is divided into blocks.  The beginning of a file is the first
      // block.  From then on, the <a name="..."> tags mark block boundaries.
      filename               = (String)filenameList.nextElement();
      blockNumber            = new char[1];
      blockNumber[0]         = currentBlock;
      title.setLength(0);
      fileEntry              = new FileEntry(filename);
      inTitle = foundTitle = false;
      fileList.addElement(fileEntry);
      blockEntry             = new BlockEntry(currentFile, "");
      blockList.addElement(blockEntry);

      try {
	input  =
	  new BufferedInputStream(new FileInputStream(indexDirectory + 
						      filename));
	filter = new HTMLTokenFilter(wordExpression, input);
	messageArea.showMessage("\nIndexing: " + filename);
				//"\nTotal Memory: " + runtime.totalMemory() +
				//" Free: " + runtime.freeMemory());
	// Iterate through tokens in the file
	while((token = filter.nextWord()) != null){
	  // If the token is not an HTML tag, index it.
	  if(token.charAt(0) != '<'){
	    // If we're in a title tag, save the token.  This could
	    // result in inexact titles if the word matching expresion
	    // does not capture punctuation.
	    if(!foundTitle && inTitle)
	      title.append(token + " ");

	    token = token.toLowerCase();

	    wordEntry = (WordEntry)wordIndex.get(token);
	    ++wordCount;

	    // If the word has already been encountered, update its entry.
	    if(wordEntry != null){
	      //++wordEntry.count;
	      // If the word has yet to occur in this block, index it.
	      if(wordEntry.lastBlock != currentBlock){
		wordEntry.lastBlock = currentBlock;
		wordEntry.blocks.addElement(blockNumber);
	      }
	    } else {
	      // If the word has yet to be encountered in the indexed
	      // documents, create a new entry for it.
	      wordEntry           = new WordEntry();
	      //wordEntry.count     = 1;
	      wordEntry.lastBlock = currentBlock;
	      wordEntry.blocks.addElement(blockNumber);
	      wordIndex.put(token, wordEntry);
	    }

	  } else {
	    String originalToken;

	    originalToken = token;
	    token = token.toLowerCase();

	    if(token.startsWith("<a")) {
	      // Start a new block if an anchor has been encountered.
	      if(anchorMatcher1.matchPrefix(originalToken) > 0){
		++currentBlock;
		blockNumber            = new char[1];
		blockNumber[0]         = currentBlock;
		anchor      = anchorMatcher1.lastMatch();
		anchorName  = anchor.group(1);
		blockEntry  = new BlockEntry(currentFile, anchorName);
		blockList.addElement(blockEntry);
	      } else if(anchorMatcher2.matchPrefix(originalToken) > 0) {
		++currentBlock;
		blockNumber            = new char[1];
		blockNumber[0]         = currentBlock;
		anchor      = anchorMatcher2.lastMatch();
		anchorName  = anchor.group(1);
		blockEntry  = new BlockEntry(currentFile, anchorName);
		blockList.addElement(blockEntry);
	      }
	    } else if(!foundTitle) {
	      if(token.equals("<title>") || token.equals("<h1>") ||
		 token.equals("<h2>") || token.equals("<h3>") ||
		 token.equals("<h4>") || token.equals("<h5>") ||
		 token.equals("<h6>"))
		inTitle = true;
	      else if(inTitle &&
		      (token.equals("</title>") || token.equals("</h1>") ||
		      token.equals("</h2>") || token.equals("</h3>") ||
		      token.equals("</h4>") || token.equals("</h5>") ||
		      token.equals("</h6>"))) {
		foundTitle = true;
		inTitle    = false;
	      }
	    }
	  }
	}

	input.close();
	// If there was no title, or the title was a run on set a default
	// title.
	if(title.length() == 0 || inTitle)
	  fileEntry.setTitle("Untitled");
	else
	  fileEntry.setTitle(title.toString());
	++currentFile;
	++currentBlock;
      } catch(IOException e){
	System.err.println("IOException caught:\n" + e);
      }
    }
    
    index            = new RawIndex();
    index.blockList  = blockList;
    index.fileList   = fileList;
    index.wordIndex  = wordIndex;
    index.wordCount  = wordCount;

    return index;
  }

}
