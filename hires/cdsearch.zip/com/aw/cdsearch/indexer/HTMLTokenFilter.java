/***
 * HTMLTokenFilter.java
 * Copyright 1996, 1997 Addison Wesley Longman.
 ***/
package com.aw.cdsearch.indexer;

import java.lang.*;
import java.io.*;

import com.aw.cdsearch.io.*;
import savarese.regex.*;

/***
 * This class is a WordFilter that extracts all strings comprised of
 * valid word characters (i.e, [0-9a-z_A-Z]) from an HTML file,
 * and additionally extracts HTML tags.  It is not a complete HTML
 * tokenizer.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 * @see HTMLFilter
 * @see WordFilter
 ***/

public class HTMLTokenFilter extends HTMLFilter {
  /***
   * Creates an HTMLTokenFilter with an associated InputStream from which
   * to generate tokens.
   *
   * @param wordExpression  A regular expression to use to represent
   *                         a word.
   * @param stream  The InputStream to be filtered by the HTMLTokenFilter.
   * @exception IOException If there is an error in binding the InputStream.
   * @exception MalformedExpression
   *            If the word expression is a bad regular expression.
   ***/
  public HTMLTokenFilter(String wordExpression, InputStream stream) 
    throws IOException, MalformedExpression {
    super(wordExpression, stream);
  }

  /***
   * This method is similar to that of its superclass, except it returns
   * HTML tags in addition to relevant Strings.
   *
   * @return The next word in the associated InputStream.  If there
   * are no more words, returns null.
   * @exception IOException  If there is an error in reading the InputStream
   * to obtain the next word.
   ***/
  public String nextWord() throws IOException {
    MatchResult match;

    if((match = tokenMatcher.search()) != null)
      return match.group(0);

    return null;
  }
}
