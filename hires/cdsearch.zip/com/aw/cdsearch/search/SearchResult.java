/***
 * SearchResult.java
 * Copyright 1996, 1997 Addison Wesley Longman.
 ***/

package com.aw.cdsearch.search;

/***
 * A class representing an individual search result.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

public final class SearchResult {
  String name, context, url;

  /***
   * @param nam     An identifier used to name the result.  Usually the
   *                 title of the HTML page.
   * @param contxt  The URL context of the result.
   * @param urlRest The remaining URL components.
   ***/
  SearchResult(String nam, String contxt, String urlRest) {
    name = nam;
    context = contxt;
    url  = urlRest;
  }

  /***
   * @return An identifier used to name the result.  Usually the
   *         title of the HTML page.
   ***/
  public String getName()    { return name; }

  /***
   * @return  The url associated with the search result.  If context() is
   *          null, this returns an entire url, otherwise it returns the
   *          remaining part of the url to be combined with the context()
   *          result.
   ***/
  public String getURL()     { return url;  }

  /***
   * @return  The context of the URL associated with the search result.  If
   *          return value is null, then url() contains the entire url.
   *          Otherwise, the return value is the principal part of the URL,
   *          to be combined with the remainder returned by url().
   ***/
  public String getContext() { return context;  }
}
