/***
 * WordFilter.java
 * Copyright 1996, 1997 Addison Wesley Longman.
 ***/
package com.aw.cdsearch.io;

import java.lang.*;
import java.io.*;

/***
 * An abstract class that is the superclass of all classes representing
 * a stream of words from an InputStream.  This class provides a different
 * kind of functionality than a tokenizer such as java.io.StreamTokenizer.
 * <p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

public abstract class WordFilter {
  /***
   * The InputStream to filter and from which to generate a stream of words.
   ***/
  protected InputStream input;

  /***
   * Assigns the parameter <b>stream</b> to the member variable <b>input</b>.
   * All subclasses are required to have a constructor with an InputStream
   * parameter.  That constructor could simply call WordFilter(stream) to bind
   * <b>input</b> to the InputStream or perform its own initialization.
   *
   * @param stream  The InputStream to be filtered by the WordFilter.
   ***/
  protected WordFilter(InputStream stream){
    input = stream;
  }

  /***
   * An abstract method required to follow the following behavior in 
   * WordFilter subclasses:
   *
   * @return The next word in the associated InputStream.  If there
   * are no more words, returns null.
   * @exception IOException  If there is an error in reading the InputStream
   * to obtain the next word.
   ***/
  public abstract String nextWord() throws IOException;
}
