/***
 * Indexer.java
 * Copyright 1996, 1997 Addison Wesley Longman.
 ***/
package com.aw.cdsearch.indexer;

import java.lang.*;
import java.io.*;
import java.util.*;

import com.aw.cdsearch.awt.*;
import savarese.regex.*;

/***
 * A simple structure storing the occurrences of a word in a block.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

final class WordEntry {
  //int count;
  /***
   * During indexing, this <b>lastBlock</b> is used to store the last
   * block in which the word occured.  That way the indexer can detect
   * if a new word occurence should be indexed.
   ***/
  char lastBlock;

  /***
   * A vector of block numbers containing the word.  Each block number
   * is stored as a char[1].
   ***/
  Vector blocks;

  /***
   * Default constructor for WordEntry.  Initializes <b>lastBlock</b> to 0 and
   * <b>blocks</b> to an empty Vector.
   ***/
  WordEntry(){
    //count  = 0;
    lastBlock = 0;
    blocks = new Vector();
  }
}


/***
 * A simple structure storing information about an indexed block.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

final class BlockEntry {
  /***
   * The a number refering to the file containing the block.  <b>fileNumber</b>
   * is used to index an array of <b>FileEntry</b> instances representing
   * the indexed files.
   ***/
  char fileNumber;

  /***
   * The HTML anchor used to name this block.
   ***/
  String anchorName;

  /***
   * Constructor for BlockEntry.
   *
   * @param fileNum  The file number of the block.
   * @param name     The anchor name of the block.
   ***/
  BlockEntry(char fileNum, String name){
    fileNumber  = fileNum;
    anchorName  = name;
  }
}


/***
 * A simple structure storing information about an indexed file.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

final class FileEntry {
  /***
   * The relative file name and title of the file.
   ***/
  String relativeName, title;

  /***
   * Constructor for FileEntry.
   *
   * @param  The name of the file relative to the root directory of the
   *         indexed files.
   ***/
  FileEntry(String relName) {
    relativeName = relName;
  }

  /***
   * Sets the title of the file.
   *
   * @param titl  The title of the file.
   ***/
  void setTitle(String titl) {
    title = titl;
  }
}

/***
 * A structure used to keep track of indexing information and write it
 * to files.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 ***/

final class RawIndex {
  /***
   * The total number of word occurences in the index.
   ***/
  int wordCount;

  /***
   * Vectors of BlockEntry and FileEntry instances respectively.
   * These contain the indexed blocks and files in the order in which they
   * were indexed.
   ***/
  Vector blockList, fileList;

  /***
   * A lookup table indexed by a String and returning the WordEntry
   * corresponding to that String if it was an indexed word.
   ***/
  Hashtable wordIndex;

  /***
   * Writes the list of blocks out to a stream that has already been
   * opened.  The format for the file is: <p>
   * 
   * int : number of words written determined by writeWordIndex <br>
   * char: number of blocks indexed <br>
   * List of block entries: <br>
   *   char: file number of block <br>
   *   byte[]: newline terminated ASCII representation of block anchor name<br>
   *
   * @param output  The already opened DataOutpuStream to which to write
   *                the index.
   * @param wordsWritten  The number of words written by writeWordIndex.
   * @exception IOException if an error occurs while writing the file.
   ***/
  void writeBlockIndex(DataOutputStream output, int wordsWritten)
    throws IOException {
    Enumeration blocks;
    BlockEntry block;

    // Output number of words.
    output.writeInt(wordsWritten);
    // Output number of blocks.
    output.writeChar(blockList.size());
    // For each block output the file number it belongs to, the name
    // of its anchor, and a newline separator.
    for(blocks = blockList.elements(); blocks.hasMoreElements();){
      block = (BlockEntry)blocks.nextElement();
      output.writeChar(block.fileNumber);
      output.writeBytes(block.anchorName);
      output.writeBytes("\n");
    }
  }


  /***
   * Writes the list of files out to a stream that has already been
   * opened.  The format for the file is: <p>
   * 
   * char: number of files indexed <br>
   * List of file entries: <br>
   *   byte[]: newline terminated ASCII representation of relative file
   *           name<br>
   *   byte[]: newline terminated ASCII representation of file title <br>
   *
   * @param output  The already opened DataOutpuStream to which to write
   *                the index.
   * @exception IOException if an error occurs while writing the file.
   ***/
  void writeFileIndex(DataOutputStream output) throws IOException {
    Enumeration files;
    FileEntry file;

    // Output number of files.
    output.writeChar(fileList.size());
    // For each file output its relative file name followed by a newline
    // and its title followed by a newline.
    for(files = fileList.elements(); files.hasMoreElements();){
      file = (FileEntry)files.nextElement();
      output.writeBytes(file.relativeName);
      output.writeBytes("\n");
      output.writeBytes(file.title);
      output.writeBytes("\n");
    }
  }


  /***
   * Writes the list of words out to a stream that has already been
   * opened.  The format for the file is: <p>
   * 
   * char: number of files indexed <br>
   * List of word entries: <br>
   *   UTF String: the word in UTF format <br>
   *   int : the number of blocks the word appears in
   *   char[]: The block numbers the word appears in.  There are as many
   *           block numbers as the previous int indicated.
   *
   * @param output  The already opened DataOutpuStream to which to write
   *                the index.
   * @param indexer The Indexer instance owning the index.  This is
   *                used to get minimum and maximum word lengths.
   * @exception IOException if an error occurs while writing the file.
   * @return The number of words actual written to the index file.
   ***/
  int writeWordIndex(DataOutputStream wordIndexStream, Indexer indexer)
    throws IOException {
    Enumeration words, blocks;
    WordEntry word;
    String key;
    int length, minWordLength, maxWordLength, wordsWritten;

    minWordLength = indexer.getMinWordLength();
    maxWordLength = indexer.getMaxWordLength();
    wordsWritten = 0;

    for(words = wordIndex.keys(); words.hasMoreElements();){
      key    = (String)words.nextElement();
      length = key.length();
      word = (WordEntry)wordIndex.get(key);
      if(!StopWords.isStopWord(key) && length >= minWordLength && 
	 length <= maxWordLength){
	wordIndexStream.writeUTF(key);
	wordIndexStream.writeInt(word.blocks.size());
	for(blocks = word.blocks.elements(); blocks.hasMoreElements();){
	  wordIndexStream.writeChar(((char[])blocks.nextElement())[0]);
	}
	wordsWritten++;
      }
    }

    return wordsWritten;
  }
}

/***
 * An abstract class representing the functions an indexer can perform.
 * This class needs to be reworked eventually.  The idea was to allow
 * subclasses to be created to index different kinds of data.  However,
 * the functionality hasn't been abstracted enough, and the class contains
 * member data that probably shouldn't (from a design perspective).  If you
 * decide to create new indexer types, you should rework this class and the
 * HTMLIndexer subclass to match a better scheme.  Ignoring the poor
 * design, in terms of extensibility, this is the base class for HTMLIndexer,
 * and is a separate abstract class mostly as a place holder to remind
 * of the possibility of future extensions.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 * @see HTMLIndexer
 ***/

public abstract class Indexer {
  /***
   * The miniumum and maximum lengths that a word must be for it
   * to be indexed.  Words of length less than <b>minWordLength</b> are not
   * indexed, words of length greater than <b>maxWordLength</b> are not
   * indexed.  The default value of <b>minWordLength</b> is 0 and the default
   * value of <b>maxWordLength</b> is <b>Integer.MAX_VALUE</b>.
   ***/
  protected int minWordLength, maxWordLength;

  //  /***
  //   * The minumum and maximum frequencies of occurrence that a word must
  //   * have to be indexed.  The values should be in the range 0 to 100,
  //   * and indicate the percentage of blocks within which a word occurs.
  //   * representing a percent, although values less than 0 are effectively 0
  //   * and values greater than 100 are effectively 100.  Words with a
  //   * frequency of occurence less than <b>minWordFrequency</b> are not
  //   * indexed, and ones with an occurence greater than
  //   * <b>maxWordFrequency</b> are not indexed.  The default value of
  //   * <b>minWordFrequency</b> is 0 and the default value of
  //   * <b>maxWordFrequency</b> is 100.
  //   ***/
  //  protected int minWordFrequency, maxWordFrequency;

  RawIndex rindex;

  /***
   * Initializes the member variables to their default values.
   ***/
  public Indexer() {
    minWordLength = 0;
    maxWordLength = Integer.MAX_VALUE;
    //minWordFrequency = 0;
    //maxWordFrequency = 100;
  }

  /***
   * Sets the values of the minimum and maximum lengths a word must be
   * to be indexed.
   ***/
  public final void setWordLengthLimits(int minLength, int maxLength) {
    minWordLength = minLength;
    maxWordLength = maxLength;
  }

  /***
   * @return The minimum length a word must be to be indexed.
   ***/
  public final int getMinWordLength()    { return minWordLength; }

  /***
   * @return The maximum length a word must be to be indexed.
   ***/
  public final int getMaxWordLength()    { return maxWordLength; }

  //  /***
  //   * Sets the values of the minimum and maximum frequencies of occurence
  //   * a word must possess to be indexed.  The frequencies are expressed
  //   * as a number between 0 and 100 indicating the percentage of blocks
  //   * within which a word occurs.
  //   ***/

  //  public final void setWordFrequencyLimits(int minFrequency,
  //					   int maxFrequency){
  //    minWordFrequency = minFrequency;
  //  maxWordFrequency = maxFrequency;
  //  }

  //  /***
  //   * @return The minimum frequency of occurence required for a word to be
  //   * indexed.  The frequency is expressed as a number between 0 and 100
  //   * indicating a percent.
  //   ***/
  //  public final int getMinWordFrequency() { return minWordFrequency; }

  // /***
  //   * @return The maximum frequency of occurence allowed for a word to be
  //   * indexed.  The frequency is expressed as a number between 0 and 100
  //   * indicating a percent.
  //   ***/
  //  public final int getMaxWordFrequency() { return maxWordFrequency; }

  /***
   * An abstract method to be implemented by subclasses.
   *
   * @param messageArea  A place to show messages during indexing.
   * @param indexDirectory The absolute path of the root directory of the files
   *                       being indexed, including the trailing /.
   * @param wordExpression  A regular expression to use to represent
   *                            a word.
   * @param filenameList  An Enumeration of file names to be indexed.  The
   *                      names should be of type String and relative to
   *                      the indexDirectory.
   * @return A RawIndex instance containing the resulting index.  Note,
   *         a better design would allow for multi-threading or an Observer
   *         to update while indexing to provide feedback.
   * @exception MalformedExpression
   *            If the word expression is a bad regular expression.
   ***/
  abstract RawIndex index(MessageArea messageArea, String indexDirectory,
			  String wordExpression, Enumeration filenameList)
    throws MalformedExpression;

  /***
   * This method is the external interface for creating an index.
   *
   * @param messageArea  A place to show messages during indexing. 
   * @param indexDirectory The absolute path of the root directory of the files
   *                       being indexed, including the trailing /.
   * @param wordExpression  A regular expression to use to represent
   *                            a word.
   * @param filenameList  An Enumeration of file names to be indexed.  The
   *                      names should be of type String and relative to the
   *                      indexDirectory.
   * @param blockIndex  The name of the block index file.
   * @param fileIndex   The name of the file index.
   * @param wordIndex   The name of the word index.
   * @exception IOException If there is an error during indexing.
   * @exception MalformedExpression
   *            If the word expression is a bad regular expression.
   ***/
  public void createIndex(MessageArea messageArea,
			  String indexDirectory, String wordExpression,
			  Enumeration filenameList, String blockIndex,
			  String fileIndex, String wordIndex)
    throws IOException, MalformedExpression {

    rindex = index(messageArea, indexDirectory, wordExpression, filenameList);

    messageArea.showMessage("\nFiles : " + rindex.fileList.size() +
                            "\nBlocks: " + rindex.blockList.size() +
                            "\nWords : " + rindex.wordIndex.size() + 
                            "\nWord Occurences: " + rindex.wordCount);

    writeIndex(messageArea, blockIndex, fileIndex, wordIndex);
  }


  /***
   * This method actually writes the index files.  It is public
   * in case after calling createIndex, you want to write the
   * index files to additional files with different names.
   *
   * @param blockIndex  The name of the block index file.
   * @param fileIndex   The name of the file index.
   * @param wordIndex   The name of the word index.
   * @exception IOException if an error occurs while writing the files.
   ***/
  public void writeIndex(MessageArea messageArea,
			 String blockIndex, String fileIndex,
			 String wordIndex)  throws IOException {
    DataOutputStream output;
    int wordsWritten;

    output =
      new DataOutputStream(new BufferedOutputStream(
			    new FileOutputStream(wordIndex)));

    messageArea.showMessage("\nWriting word index to: " + wordIndex);
    wordsWritten = rindex.writeWordIndex(output, this);
    messageArea.showMessage("\nWrote " + wordsWritten + " words.");
    output.close();

    output =
      new DataOutputStream(new BufferedOutputStream(
			    new FileOutputStream(blockIndex)));
    messageArea.showMessage("\nWriting block index to: " + blockIndex);
    rindex.writeBlockIndex(output, wordsWritten);
    output.close();

    output =
      new DataOutputStream(new BufferedOutputStream(
			    new FileOutputStream(fileIndex)));
    messageArea.showMessage("\nWriting file index to: " + fileIndex);
    rindex.writeFileIndex(output);
    output.close();
  }
}
