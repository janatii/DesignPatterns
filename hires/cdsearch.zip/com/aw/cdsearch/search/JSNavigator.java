/***
 * JSNavigator.java
 * Copyright 1996, 1997 Addison Wesley Longman.
 ***/
package com.aw.cdsearch.search;

import java.net.URL;
import java.applet.Applet;

/***
 * A class implementing the Navigator interface, but using JavaScript and
 * LiveConnect to control the browser.<p>
 *
 * Copyright &#169 1996, 1997 Addison Wesley Longman.<p>
 *
 * @author Daniel F. Savarese
 * @see Navigator
 ***/

public final class JSNavigator implements Navigator {
  netscape.javascript.JSObject window;

  /***
   * Default constructor.
   ***/
  public JSNavigator() {
    window = null;
  }

  /***
   * Displays a URL in the Navigator's associated context.
   *
   * @param url  The URL to display.
   ***/
  public void showDocument(URL url) {
    String command;

    if(window != null){
      //command = "open(\"" + url.toString() + "\",\"" + "_top" + "\")";
      command = "location=\"" + url.toString() + "\"";
      window.eval(command);
    }
  }

  /***
   * Initializes the Navigator, giving the name of the display target
   * and a reference to the applet that is running in the browser to
   * be used as a display.
   *
   * @param name  The name of the display frame.  This can hold the same
   *        values as the <b>target</b> parameter of the AppletContext
   *        showDocument(URL url, String target) method.
   * @param applet  The applet whose context should be used by the Navigator.
   ***/
  public void init(String name, Applet applet) {
    window = netscape.javascript.JSObject.getWindow(applet);
    window = (netscape.javascript.JSObject)window.getMember("parent");
  }

}
